package akshaykanehitlu.topquiz.gui;

public interface SubjectListener {
	public void subjectChosen(String subject);

}
