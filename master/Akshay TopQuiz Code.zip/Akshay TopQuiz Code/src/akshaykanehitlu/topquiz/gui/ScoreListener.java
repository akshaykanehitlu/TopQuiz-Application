package akshaykanehitlu.topquiz.gui;

public interface ScoreListener {
	public void scoreUpdated(int score);

}
