package akshaykanehitlu.topquiz.gui;
public interface SummaryListener {
	public void quizEnded(ScoreSummary summary);
}