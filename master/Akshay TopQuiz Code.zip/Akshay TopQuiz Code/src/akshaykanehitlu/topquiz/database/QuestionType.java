package akshaykanehitlu.topquiz.database;

public enum QuestionType {
	MULTIPLECHOICE,
	IMAGEQUESTION,
	IMAGEANSWER
}
