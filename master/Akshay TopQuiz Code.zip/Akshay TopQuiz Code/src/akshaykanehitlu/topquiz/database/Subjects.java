package akshaykanehitlu.topquiz.database;

public enum Subjects {
	ANIMALS,
	GEOGRAPHY,
	SPELLINGS
}
